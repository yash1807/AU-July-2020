package spring_maven_mcv.com.mvc.spring.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import spring_maven_mcv.com.mvc.spring.model.Student;

@Service
public class StudentService {
	
	static ArrayList<Student> list = new ArrayList<Student>();
	
	public boolean insert( Student obj){
	   for (Student student : list) {
			if(student.getId() == obj.getId())		// Check if the Id already exists		
				return false;
		}
		list.add(obj);
		return true;
	}
	
	public boolean update(int id, Student obj){
		if(delete(id)){
			insert(obj);
			return true;
		}
		return false;
	}
	
	public boolean delete(int id){
		for (Student student : list) {
			if(student.getId() == id){
				list.remove(student);
				return true;
			}
		}
		return false;
	}
	
	public Student getStudent(int id){
		for (Student student : list) {
			if(student.getId() == id)
				return student;			
		}
		return null;
	}
	
	
	public ArrayList<Student> getAlldata(){
		return list;
	}
}
