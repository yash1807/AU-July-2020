package spring_maven_mcv.com.mvc.spring.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {


	@ExceptionHandler(InvalidIdError.class)
	public ModelAndView InvalidIdError(HttpServletRequest req, Exception ex)
	{
		
		ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("exception", ex);
	    modelAndView.addObject("url", req.getRequestURL());
	    
	    modelAndView.setViewName("error");
	    return modelAndView;		
	}
	
	@ExceptionHandler(DuplicateIdError.class)
	public ModelAndView DuplicateIdError(HttpServletRequest req, Exception ex)
	{
		
		ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("exception", ex);
	    modelAndView.addObject("url", req.getRequestURL());	    
	    modelAndView.setViewName("error");
	    return modelAndView;		
	}
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(HttpServletRequest req, Exception ex)
	{
		
		ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("exception", ex);
	    modelAndView.addObject("url", req.getRequestURL());	    
	    modelAndView.setViewName("error");
	    return modelAndView;		
	}
}
